file = open("historicalText.txt","r+")
his = file.readlines()
file = open("shortText.txt","r+")
shortText = file.readlines()
longWord = []
shortWord = []



for i in range(0,len(shortText)):
	longWord.append(shortText[i].split(":")[0])
	shortWord.append(shortText[i].split(":")[1].split("\n")[0])

output = []

# for i in range(len(his)):
# 	for y in range(0,len(longWord)):
# 		his[i] = ((his[i].lower().replace(longWord[y],shortWord[y])))

final = ''

for i in range(len(his)):
	final += his[i] + "\n"

#print(final.split("\n")[0],"\n\n",final.split("\n")[-2])

final = final.split("\n")[0],final.split("\n")[-2]

dictionary= longWord
fakeDictionary= []

trueFinish = ""
for i in range(0,len(final[0].split("."))):
	fakeDictionary += final[0].split()[i].split()
	if (len(fakeDictionary[i])) >3:
		dictionary+=final[0].split()[i].split()

print(dictionary)


for i in range(len(final)):
	for y in range(len(final[i].split("."))):
		for z in range(len(dictionary)):
			if dictionary[z] in final[i].split()[y].lower() :
				trueFinish+=final[i].split(".")[y]+" "

print(trueFinish)
